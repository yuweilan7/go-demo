---
name: go-learning-by-running
description: "Turn Go tutorials, concept-heavy explanations, and learning-oriented Go code into plain-language teaching plus runnable, heavily commented examples inside the user's current project. Use when the user supplies Go learning material or asks to learn or compare Go concepts by running code; do not use for ordinary production feature work, bug fixes, or code review unless teaching artifacts are requested."
---

# Go Learning By Running

Convert Go learning material into an experience the user can understand in conversation and verify by running real project files.

## Learner and teaching strategy

- Assume the user is new to Go but is a senior Java engineer who already understands Java, concurrency, the Java Memory Model, JVM behavior, garbage collection, and common Java libraries. Do not reteach Java foundations unless asked.
- Explain each topic from a Go-native mental model first. The lesson should teach Go itself, not recast every Go feature as a Java feature.
- Select the most useful combination of teaching angles for the supplied material rather than following one rigid template:
  - plain-language Go semantics and the reason the feature behaves that way;
  - Go-to-Go contrasts between easily confused constructs, such as arrays and slices, `new` and `make`, value and pointer receivers, or buffered and unbuffered channels;
  - common traps, invalid intuitions, compiler errors, runtime surprises, and outdated claims in the source;
  - runnable observations that make types, values, copying, mutation, ordering, blocking, or visibility concrete;
  - Java/JVM/JMM comparisons when familiar concepts provide a faster route to understanding.
- Treat Java comparisons as an optional accelerator, including in conversational explanations and code comments. Use them when Go-only wording is awkward, when a Java analogy makes the idea click faster, or when Java instincts are likely to cause a mistake.
- When using a Java analogy, identify the important semantic difference or boundary when needed. Never imply exact equivalence with shortcuts such as “a goroutine is just a Java thread” or “a channel is Go's `BlockingQueue`.”
- Vary the depth and angles according to the topic. Do not force every concept to include a Java comparison, every possible contrast, or every category above.

## Required outcome

Deliver all three parts unless the user explicitly declines one:

1. Explain the supplied Go concepts in plain language, using accurate mental models and correcting misleading claims in the source.
2. Create one runnable `.go` file or a focused directory of multiple `.go` files in the user's current project. Do not merely paste hypothetical code into chat.
3. Format and run the example, then report the exact command, important output, and created file paths.

## Build the learning example

- Inspect `go.mod`, relevant existing files, and local project instructions before choosing paths or imports.
- Preserve the user's existing application. Prefer a dedicated directory such as `examples/<topic>` when adding another `package main` at the module root would conflict or when the lesson benefits from several files.
- Derive local import paths from the `module` directive in `go.mod`; never copy a tutorial's placeholder module path blindly.
- Keep one package per ordinary directory. Prefer conventional lowercase directory and package names, while explaining when the source material uses a technically legal but confusing mismatch.
- Use multiple files when package boundaries, exported identifiers, file organization, initialization, or collaboration between files is part of the lesson. Use one file when splitting adds no teaching value.
- Add detailed Chinese comments near the code they explain. Comments should clarify behavior and tradeoffs, not paraphrase every token.
- Use comments to surface the most helpful mix of Go mechanics, Go-to-Go contrasts, pitfalls, and occasional Java comparisons. Do not clutter obvious syntax or require a Java comparison where Go explains itself clearly.
- Make runtime output a teaching aid: add clear section labels and print side-by-side contrasts, values, types, call order, or visibility behavior when those dimensions matter.
- Cover several relevant contrasts from the supplied material, but do not add unrelated language features just to make the example large.
- Code that intentionally does not compile belongs only in comments, next to the expected compiler error and corrected form; the runnable example itself must compile.
- For concurrency or memory-model lessons, distinguish language guarantees from current runtime implementation details. Prefer runnable observations that demonstrate synchronization and ownership; if an intentional data race is pedagogically necessary, isolate it clearly and verify it with `go test -race` or `go run -race` when supported.

## Verify

Run `gofmt` on created or edited Go files. Prefer `go run ./<example-directory>` for the demonstration and use `go test` on the affected packages or `go test ./...` when appropriate. If the lesson discusses binaries, also run `go build` with an explicit output path that does not overwrite user artifacts. Do not leave generated binaries in the repository unless requested.

If verification fails, diagnose and repair teaching code before handing it off. Distinguish an actual code failure from an IDE, PATH, network, or sandbox limitation.

## Teach in the response

Lead with what was created and whether it ran. Then explain:

- the smallest useful mental model;
- the most useful Go-native contrasts, pitfalls, runnable observations, and optional Java/JVM analogy for this particular topic;
- how each file participates;
- the meaningful comparisons visible in output;
- inaccuracies or outdated conventions in the supplied material;
- the commands the user can rerun and one or two safe experiments they can try.

Link to the actual files. Keep the chat explanation aligned with the generated code and observed output. Never claim a command succeeded unless it was run successfully.
